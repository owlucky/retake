package com.example.integral.entities;

import jakarta.persistence.*;
import lombok.Data;
import lombok.extern.java.Log;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
@Entity
@Data
@Table(name = "Проект")
public class Project {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "Название")
    private String title;
    @ManyToOne
    @JoinColumn(name = "Код_студента", referencedColumnName = "Id")
    Student author;
    @Column(name = "Описание")
    private String description;
    @Lob
    @Column(name = "Картинка", columnDefinition = "varbinary(max)")
    private byte[] file1;
    @Lob
    @Column(name = "Чертеж", columnDefinition = "varbinary(max)")
    private byte[] file2;
    @Lob
    @Column(name="Документация", columnDefinition = "varbinary(max)")
    private byte[] file3;
}
