package com.example.integral.services;

import java.util.List;

public interface ServiceAble<T> {
    T findById(Long id);
    List<T> findAll();
    void insert(T obj);
    void delete(T obj);
    void update(T obj);
}
