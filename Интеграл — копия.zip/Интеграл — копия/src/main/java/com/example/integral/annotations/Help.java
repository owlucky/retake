package com.example.integral.annotations;

public class Help {
    public static boolean isnotblank(String item) {
        if (item == null && item == "") return false;
        return true;
    }
}
