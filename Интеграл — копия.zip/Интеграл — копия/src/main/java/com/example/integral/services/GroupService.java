package com.example.integral.services;

import com.example.integral.entities.Group;
import com.example.integral.repositories.GroupRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupService implements ServiceAble<Group>{
    @Autowired
    GroupRepository groupRepository;
    @Override
    public List<Group> findAll(){
        return groupRepository.findAll();
    }
    @Override
    public void insert(Group group){
        groupRepository.save(group);
    }
    @Override
    public void delete(Group group){
        groupRepository.delete(group);
    }

    @Override
    public void update(Group obj) {
        groupRepository.save(obj);
    }

    @Override
    public Group findById(Long id){
        return groupRepository.getReferenceById(id);
    }

}
