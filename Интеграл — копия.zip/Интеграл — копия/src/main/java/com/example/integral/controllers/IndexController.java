package com.example.integral.controllers;

import com.example.integral.entities.Project;
import com.example.integral.entities.Student;
import com.example.integral.services.ProjectService;
import com.example.integral.services.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
@RequiredArgsConstructor
public class IndexController {
    private final StudentService studentService;
    private final ProjectService projectService;
//    @GetMapping("/")
//    public String index(Model model) {
//        // (создали пустой объект для заполнения)//        model.addAttribute("project", new Project());//внешняя связь с данными
//        model.addAttribute("projects",projectService.findAll()); //внешняя связь с данными
//        return "index"; //название шаблона (файлика html)
//    }

//    @PostMapping("/project/create")
//    public String createProject(Project project){
//        projectService.insert(project);
//        return "redirect:/";
//    }

//    @GetMapping("/student/{id}")
//    public String studentInfo(@PathVariable Long id, Model model) {
//        model.addAttribute("student", studentService.getStudentById(id));
//        return "student-info";
//    }
//
//    @PostMapping("/student/create")
//    public String createStudent(Student student) {
//        studentService.saveStudent(student);
//        return "redirect:/";
//    }
//
//    @PostMapping("/student/delete/{id}")
//    public String deleteStudent(@PathVariable Long id) {
//        studentService.deleteStudent(id);
//        return "redirect:/";
//    }
}
