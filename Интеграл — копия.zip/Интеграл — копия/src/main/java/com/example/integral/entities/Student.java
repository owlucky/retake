package com.example.integral.entities;

import com.example.integral.annotations.Check;
import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Entity
@Table(name = "Студент")
@Check
@Data
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @Column(name = "Имя")
    String name;
    @Column(name = "Фамилия")
    String surname;
    @Column(name = "Отчество")
    String patronymic;
    @OneToMany(mappedBy = "author", cascade = CascadeType.ALL)
    List<Project> projects;
    @ManyToOne
    @JoinColumn(name = "Код_группы", referencedColumnName = "Id")
    Group group;
    @Column(name = "Номер_зачётки")
    Integer numberBook;
//    @Column(name = "Оценки")
//    List<Integer> grades;
}
