package com.example.integral.services;

import com.example.integral.entities.Project;
import com.example.integral.repositories.ProjectRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;
@Service
@Slf4j
@RequiredArgsConstructor
public class ProjectService implements ServiceAble<Project>{
    @Autowired
    ProjectRepository projectRepository;
    @Override
    public Project findById(Long id) {
        return projectRepository.findById(id).orElse(null);
    }

    @Override
    public List<Project> findAll() {
        return projectRepository.findAll();
    }

    @Override
    public void insert(Project obj) {
        projectRepository.save(obj);
    }

    public void save(Project project) throws IOException {
        projectRepository.save(project);
    }

    @Override
    public void delete(Project obj) {
        projectRepository.delete(obj);
    }

    @Override
    public void update(Project obj) {
        projectRepository.save(obj);
    }
    public List<Project> findProjects(String title) {
        if (title != null) return projectRepository.findByTitle(title);
        return projectRepository.findAll();
    }
    public void saveProject(Project project, MultipartFile file1, MultipartFile file2, MultipartFile file3) throws IOException {
        projectRepository.save(project);
    }

}
