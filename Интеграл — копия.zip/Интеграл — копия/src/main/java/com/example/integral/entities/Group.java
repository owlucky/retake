package com.example.integral.entities;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "Группа", schema = "dbo")
public class Group {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @Column(name = "Название")
    String name;

    @OneToMany(mappedBy = "group", cascade = CascadeType.ALL)
    List<Student> students;
    @ManyToOne
    @JoinColumn(name = "Код_института", referencedColumnName = "Id")
    Institute institute;
}
