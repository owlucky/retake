package com.example.integral.entities;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "Институт")
public class Institute {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @Column(name = "Название")
    String name;

    @OneToMany(mappedBy = "institute", cascade = CascadeType.ALL)
    List<Group> groups;
}
