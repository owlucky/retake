package com.example.integral.DAO;

import lombok.Data;

@Data
public class ProjectSearchForm {
    private String title;
}
