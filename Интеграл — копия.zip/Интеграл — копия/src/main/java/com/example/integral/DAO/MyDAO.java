package com.example.integral.DAO;

import org.springframework.stereotype.Repository;

@Repository
public class MyDAO {
}
