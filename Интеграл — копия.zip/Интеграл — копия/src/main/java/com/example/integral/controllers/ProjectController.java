package com.example.integral.controllers;
import com.example.integral.DAO.ProjectSearchForm;
import com.example.integral.entities.Project;
import com.example.integral.entities.Student;
import com.example.integral.services.ProjectService;
import com.example.integral.services.StudentService;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import java.util.Base64;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

@Controller
@RequiredArgsConstructor
public class ProjectController {

    private final ProjectService projectService;

    @GetMapping("/")
    public String projects(@RequestParam(name = "title", required = false) String title, Model model) {
        ProjectSearchForm form = new ProjectSearchForm();
        form.setTitle(title);
        model.addAttribute("form", form);
        model.addAttribute("projects", projectService.findProjects(title));
        model.addAttribute("project", new Project());
        return "index";
    }
    @GetMapping("/project/{id}")
    public String productInfo(@PathVariable Long id, Model model) {
        Project project = projectService.findById(id);
        model.addAttribute("project", project);
        return "project-info";
    }

    @PostMapping("/project/create")
    public String createProduct(Project project, @RequestParam("file1") File file1, @RequestParam("file2") File file2,
                                @RequestParam("file3") File file3) throws IOException {
        projectService.save(project);
        if (file1 != null) {
            byte[] file11;
            file11 = new byte[(int) file1.length()];
            System.out.println(file11);
            project.setFile1(file11);
        }
        if (file2 != null) {
            byte[] file12;
            file12 = new byte[(int) file2.length()];
            project.setFile2(file12);
        }
        if (file3 != null) {
            byte[] file13;
            file13 = new byte[(int) file3.length()];
            project.setFile3(file13);
        }
//        if (file2.getSize() > 0) project.setFile2(file2.getBytes());
//        if (file3.getSize() > 0) project.setFile3(file3.getBytes());
        return "redirect:/";
    }

    @PostMapping("/product/delete/{id}")
    public String deleteProduct(@PathVariable Project project) {
        projectService.delete(project);
        return "redirect:/";
    }
}