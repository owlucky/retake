package com.example.integral.entities;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "Пользователь")
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "Логин")
    private String username;
    @Column(name="Пароль")
    private String password;
//    @Column(name="Активность")
//    private boolean active;
//    @Column(name="Почта", unique = true)
//    private String email;
//    @ElementCollection(targetClass = Role.class, fetch = FetchType.EAGER)
//    @CollectionTable(name="Роль_пользователя", joinColumns = @JoinColumn(name="Код_пользователя"))
//    @Enumerated(EnumType.STRING)
//    private Set<Role> roles = new HashSet<>();
//    private LocalDateTime dateOfCreated;
//    @PrePersist
//    private void init(){
//        dateOfCreated = LocalDateTime.now();
//    }
//
//    @Override
//    public Collection<? extends GrantedAuthority> getAuthorities() {
//        return roles;
//    }
//    @Override
//    public String getUsername(){
//        return email;
//    }
//    @Override
//    public boolean isAccountNonExpired() {
//        return true;
//    }
//
//    @Override
//    public boolean isAccountNonLocked() {
//        return true;
//    }
//
//    @Override
//    public boolean isCredentialsNonExpired() {
//        return true;
//    }
//
//    @Override
//    public boolean isEnabled() {
//        return active;
//    }
}
