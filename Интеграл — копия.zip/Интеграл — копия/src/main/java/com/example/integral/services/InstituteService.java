package com.example.integral.services;

import com.example.integral.entities.Group;
import com.example.integral.entities.Institute;
import com.example.integral.repositories.GroupRepository;
import com.example.integral.repositories.InstituteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class InstituteService implements ServiceAble<Institute>{
    @Autowired
    InstituteRepository instituteRepository;
    @Override
    public Institute findById(Long id) {
        return instituteRepository.getReferenceById(id);
    }

    @Override
    public List<Institute> findAll() {
        return instituteRepository.findAll();
    }

    @Override
    public void insert(Institute obj) {
        instituteRepository.save(obj);
    }

    @Override
    public void delete(Institute obj) {
        instituteRepository.delete(obj);
    }

    @Override
    public void update(Institute obj) {
        instituteRepository.save(obj);
    }
}
