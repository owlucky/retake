package com.example.integral.configs;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.spring6.view.ThymeleafViewResolver;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

@Configuration
public class MVCconfig implements WebMvcConfigurer {
    // объясняем java какие файлики обрабатывать
    @Bean
    public ClassLoaderTemplateResolver templateResolver(){
        ClassLoaderTemplateResolver loader = new ClassLoaderTemplateResolver();
        loader.setPrefix("/templates/");
        loader.setSuffix(".html");
        return loader;
    }
    //складываем найденное в обработчик html
    @Bean
    public SpringTemplateEngine templateEngine(){
        SpringTemplateEngine engine = new SpringTemplateEngine();
        engine.setTemplateResolver(templateResolver());
        return engine;
    }
    //указываем обработчик представлений для которого устанавливаем обработчик html
    @Override
    public void configureViewResolvers(ViewResolverRegistry registry){
        ThymeleafViewResolver viewResolver = new ThymeleafViewResolver();
        viewResolver.setTemplateEngine(templateEngine());
        registry.viewResolver(viewResolver);
    }

}
