package com.example.integral.services;

import com.example.integral.entities.Institute;
import com.example.integral.entities.Student;
import com.example.integral.repositories.InstituteRepository;
import com.example.integral.repositories.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class StudentService implements ServiceAble<Student>{
    @Autowired
    StudentRepository studentRepository;
    @Override
    public Student findById(Long id) {
        return studentRepository.getReferenceById(id);
    }

    @Override
    public List<Student> findAll() {
        return studentRepository.findAll();
    }

    @Override
    public void insert(Student obj) {
        studentRepository.save(obj);
    }

    @Override
    public void delete(Student obj) {
        studentRepository.delete(obj);
    }

    @Override
    public void update(Student obj) {
        studentRepository.save(obj);
    }
}
