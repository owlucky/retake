import java.net.ConnectException;
import java.sql.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Main {
    public static void main(String[] args){
        String url = "jdbc:sqlserver://localhost;databaseName=INTEGRAL;port=1433;trustServerCertificate=true;encrypt=true;integratedSecurity=true;useUnicode=true; connectionCollation=utf8_general_ci;characterSetResults=utf8;characterEncoding=utf-8";
        String user = "Anastasiya";
        String password = "qwerty123";
    }
}
